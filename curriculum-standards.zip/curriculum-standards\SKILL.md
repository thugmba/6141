---
name: curriculum-standards
description: >-
  Authoritative standards and procedural runbook for authoring university-level business/MBA courses,
  16-session modular curriculums, 16:9 widescreen presentation slide decks, audited spreadsheet labs,
  hands-on coding environments, and term project guidelines. Supports both Theoretical/Strategy and
  Applied Coding/Hands-on course tracks. Activate this skill whenever creating, updating, or reviewing
  course syllabi, lecture presentations, classroom exercises, or academic learning materials.
---

# University Curriculum & Lecture Presentation Standards

This skill provides comprehensive pedagogical specifications, structural templates, slide deck design systems, and quality assurance checklists for developing professional business, management, analytics, and coding courses.

---

## 0. Mandatory Course Track Selection Gatekeeper

When creating or revising a course, the agent **MUST** first determine the track of the course.

* **Explicit User Choice:** If the user states the track (e.g., "경영전략 과목", "파이썬 코딩 과목"), immediately adopt that track.
* **Underspecified / Ambiguous Requests:** If the user asks to build a course without explicitly specifying whether it is theory/strategy-based or coding/hands-on, the agent **MUST NOT** make an assumption. The agent **MUST prompt the user** using `ask_question` with the following two options:
  1. `(Recommended) 실습/프로그래밍 중심 과목 (Applied Coding & Data Science Track)`: Hands-on coding, Python/SQL scripts, Google Antigravity IDE, syntax mastery, and AI debugging. Zero corporate showdowns; zero abstract management theories.
  2. `이론/경영전략 중심 과목 (Business Strategy & Analytical Theory Track)`: Management frameworks, academic theories (TAM, RBV), SEC 10-K enterprise case studies, corporate A vs. B showdowns, and CFO/CEO decision memos.

---

## 1. Pedagogical Profile & Audience Guidelines

* **Target Audience:**
  * Undergraduate and graduate (MBA) business college students.
  * Non-native English speakers.
  * Assumed to have zero prior academic or technical background in the subject matter.
* **Tone & Register:**
  * Authoritative, direct, encouraging, clear, and business-grounded.
  * Avoid convoluted academic jargon or ungrounded software engineering abstractions.
* **Language Requirement (100% US English):**
  * All curriculum documentation, markdown files (`.md`), lecture presentation slides (`.pdf`), diagrams, and visual image assets (`.png`, `.webp`) must be authored exclusively in English (US English).
  * Non-English text, secondary language annotations, or bilingual translations are strictly barred across all assets.
* **Mandatory Acronym Expansion (Zero Exception Rule):**
  * Whenever financial, accounting, operational, or technical acronyms (e.g., PP&E, CapEx, OpEx, CAC, LTV, ARR, GMV, EBITDA, REPL, IDE, DOM, POS) are introduced, the full term must be explicitly defined upon first use (e.g., `Integrated Development Environment (IDE)`).
  * Every specialized acronym must be paired with an intuitive, plain-language explanation of its real-world operational meaning.
* **Interactive 3-Hour Session Rhythm (1:2 Delivery Ratio):**
  * Maximum Interactivity Principle: Courses must minimize passive lecture delivery and maximize hands-on student execution.
  * Lecture Phase (Approx. 1 Hour / 60 Minutes): Concise instruction covering keywords, foundational frameworks, and intuitive micro-examples.
  * Hands-On Practice & Problem-Solving Phase (Approx. 2 Hours / 120 Minutes):
    * Track A: Students manipulate audited spreadsheets and formulate strategic decisions.
    * Track B: Students write executable scripts in the IDE, trigger errors, and partner with AI to debug code.
* **Mandatory Two-Tier Exercise Architecture:**
  * Every session must include a minimum of two structured exercises with ascending difficulty:
    * Exercise 1 (Foundational / Simple): Guided, step-by-step lab protocol ensuring baseline operational competency.
    * Exercise 2+ (Advanced / Complex):
      * Track A: Unstructured strategic dilemma culminating in a 3-bullet executive decision memo to the Board/CEO.
      * Track B: Applied coding challenge expanding the script, diagnosing an intentional error, and verifying execution.

---

## 2. Structural Curriculum Architecture (Common across all tracks)

* **Modular Framework:** Exactly 4 Modules per course; exactly 4 Sessions per Module (16 Sessions total).
* **Course Promotional Image (16:9 Banner):**
  * Positioned at the very top of the syllabus document (`assets/course_banner.png`).
  * Canvas Background Color: **Pure White (`#FFFFFF`)**. Dark mode or colored backgrounds are strictly prohibited to ensure visual unity with the academic syllabus document.
  * Resolution & Format: 16:9 widescreen format (1920x1080 resolution), PNG or WebP.
* **Session Summary Presentation Slide (16:9 Preview Image):**
  * Positioned immediately under each session heading (`assets/session_X-Y_slide.png`).
  * Canvas Background Color: **Pure White (`#FFFFFF`)**. Dark mode or colored backgrounds are strictly prohibited for summary slides to ensure seamless visual harmony with academic white documents.
  * Resolution & Format: 16:9 widescreen format (1920x1080 resolution), PNG format.
* **Clickable Table of Contents (TOC):**
  * Positioned preceding Module 1.
  * Bidirectional Anchor Matching: Every TOC link (`[Session X.Y: Title](#session-X-Y)`) must pair with an exact HTML anchor tag (`<a id="session-X-Y"></a>`).

---

## 3. Standardized Session Content Templates

### [Track A Template] Business Strategy & Analytical Theory Track

Use this template for strategy, management, corporate finance, and business valuation courses.

```markdown
<a id="session-X-Y"></a>
### Session X.Y: [Descriptive Business Strategy Title]

![Session X.Y Summary Slide](assets/session_X-Y_slide.png)

* **Lecture Presentation:** [Download Slides (PDF)](slides/session_X_Y_lecture.pdf)

* **Keywords:** 4 to 5 business/financial metrics with full acronym expansions.
* **Main Theories:**
  * [Theory 1](active-link): Author (Year) and seminal framework description.
  * [Theory 2](active-link): Economic model and market mechanism.
* **Micro-Examples:**
  * 3 concise, intuitive cross-industry examples illustrating the concept in corporate operations.
* **Real Business Case:**
  * Longitudinal enterprise case study tied to verifiable multi-year historical numbers from SEC filings.
* **Lab Dataset:**
  * File Link: [data/session_X_Y_dataset.csv](data/session_X_Y_dataset.csv)
  * Columns: Standardized unit suffix taxonomy (`_USD_M`, `_Pct`, `_Count`, `Filing_Source`).
* **Primary Filings & External References:**
  * Official regulatory filings (SEC EDGAR Form 10-K) and seminal academic literature.
* **Step-by-Step Lab Protocol (Exercise 1: Foundational Practice):**
  * Step-by-step Excel spreadsheet calculation with explicit cell coordinates (e.g., `=C13-E13`).
* **Step-by-Step Strategic Decision Challenge (Exercise 2+: Advanced Problem Solving):**
  * Unstructured executive dilemma culminating in a 3-bullet decision brief addressed to the Board of Directors or CEO.
```

---

### [Track B Template] Applied Programming & Hands-On Track

Use this template for Python, SQL, web scraping, data wrangling, and applied machine learning courses.
**STRICT PROHIBITION:** Do NOT include abstract management theories (TAM, RBV), corporate A vs. B strategy showdowns, or CFO CapEx memos in Track B.

```markdown
<a id="session-X-Y"></a>
### Session X.Y: [Descriptive Applied Programming Title]

![Session X.Y Summary Slide](assets/session_X-Y_slide.png)

* **Lecture Presentation:** [Download Slides (PDF)](slides/session_X_Y_lecture.pdf)

* **Keywords (Core Programming Concepts):**
  * 4 to 5 computing/programming terms (e.g., Interpreter, Variable Assignment, Data Types, Traceback, IDE).
* **Core Programming & Computational Foundations:**
  * Sequential Execution & Program Flow: Line-by-line execution and memory state mechanics.
  * Spreadsheet Coordinates vs. Named Variables: Transitioning from fragile cells (`C13`) to self-documenting code.
  * Interpreter Diagnostics & Traceback Mechanics: Reading line numbers and error categories calmly as navigation clues.
* **Hands-On Coding Micro-Examples:**
  * Micro-Example 1: Executable variable definition and commercial arithmetic (`+`, `-`, `*`, `/`).
  * Micro-Example 2: Dynamic parameter reusability (changing one variable recalculates all downstream metrics).
  * Micro-Example 3: Traceback troubleshooting (triggering an intentional typo and verifying the fix).
* **Lab Practice Dataset:**
  * File Link: [data/session_X_Y_dataset.csv](data/session_X_Y_dataset.csv)
  * Simple, clean tabular CSV dataset used to ingest, verify, or manipulate in code.
* **Official Documentation & Technical References:**
  * Links to official Python/Pandas documentation, PEP 8 style guide, and IDE quickstart guides.
* **Integrated Development Environment Architecture (Google Antigravity IDE):**
  * Visual screenshot asset: `![Google Antigravity IDE Interface](assets/antigravity_ide_interface.png)`.
  * The 4 Workspace Panels: `[1] File Explorer`, `[2] Code Editor`, `[3] AI Agent Chat`, `[4] Integrated Terminal`.
  * AI Error Diagnosis Protocol:
    1. Identify: Check error type on the last line of Terminal `[4]` (`NameError`, `SyntaxError`, `TypeError`).
    2. Capture: Press `Win + Shift + S` (macOS: `Cmd + Shift + 4`) to clip the error snippet.
    3. Paste: Press `Ctrl + V` into AI Chat `[3]` and ask: *"Why did this error happen and how to fix it?"*
    4. Apply: Review root cause and copy the verified fix into Code Editor `[2]`.
* **Step-by-Step Lab Protocol (Exercise 1: Guided Practice):**
  * Opening the IDE, creating a `.py` file, assigning variables, computing formulas, using `print()` and `round()`, and running the script in the terminal.
* **Step-by-Step Applied Coding Practice (Exercise 2+: Hands-On Programming & Debugging):**
  * Expanding the script with a secondary segment/calculation, triggering an intentional syntax error, screenshotting the traceback into AI Chat, and verifying error-free execution (Exit 0).
```

---

## 4. Lecture Slide Presentation Deck (16:9 Multi-Page PDF Specifications)

* **Common Universal Fixed Frame (Zero Vertical Drift Mandate):**
  * Canvas: `@page { size: 16in 9in; margin: 0; }` with `-webkit-print-color-adjust: exact;`.
  * Canvas Background: **Pure White (`#FFFFFF`)** across all slide canvases.
  * Harvard Crimson Accent Line: `height: 4px; background: #991B1B;`.
  * Header Area: `top: 0.55in; height: 1.35in; left: 0.8in; right: 0.8in;`.
  * Body Content Area: `top: 2.15in; bottom: 1.1in; left: 0.8in; right: 0.8in;` (Height = `5.75in`).
  * Footer Area: `bottom: 0.45in; height: 0.5in; left: 0.8in; right: 0.8in;`.
  * Sub-Pixel Alignment: Footer text baseline locked across all pages (`y0 = 595.14 pt` within +/- 0.5pt).
  * Typography: Times New Roman baseline font; universal font floor of 15px; cards/lists minimum 19px-20px.
  * Zero AI Box Left Lines: No `border-left` lines; use balanced 4-sided borders.

* **Track A Specific Slide Requirements:**
  * **Dedicated A vs. B Showdown Slides:** Side-by-side corporate benchmark cards with vector brand logos, contrasting cool vs. warm palettes, and 3-pillar SEC Form 10-K operational metrics.
  * **Executive Decision Slide:** Boardroom dilemma framing and structured 3-bullet decision deliverable.

* **Track B Specific Slide Requirements:**
  * **Zero Showdowns:** Abstract corporate A vs. B showdowns are barred from programming slides.
  * **Style 2 Harvard Academic Dual-Pane Code Editor (Mandatory for Code Slides):**
    * Left Pane: Dark IDE Editor (`background: #18181B;`) with macOS window dots, file tab, line numbers (`line-gutter`), multi-line code (`<pre class="code-block">` with `white-space: pre;`), and Terminal output bar.
    * Right Pane: Line-by-line 3-card business or diagnostic anatomy stack explaining variable assignment, formula equivalence, and formatting.
  * **Development Environment Slide:**
    * Displays Google Antigravity IDE 4-panel architecture (`[1] Explorer`, `[2] Code Editor`, `[3] AI Chat`, `[4] Terminal`) using embedded screenshot asset.
    * Features the zero-friction `Win + Shift + S` -> `Ctrl + V` error capture and resolution protocol.

---

## 5. Lab Datasets, Spreadsheet & Coding Environment Standards

* **Track A Environment:**
  * Microsoft Windows (US English Edition), US English Excel formulas with comma arguments (e.g., `=IF(D2>0, D2/C2*100, 0)`).
* **Track B Environment:**
  * Python 3.10+ in Google Antigravity IDE.
  * Column Naming Taxonomy: `_USD_M`, `_USD`, `_Pct`, `_Count`, `_Units`.
  * Audited datasets stored in `data/` folder in standard comma-separated format.

---

## 6. Strict Editorial Invariants (Applicable to ALL Tracks)

* **Internal Scope Isolation:** Developer rules and prompt instructions must NEVER appear within student-facing syllabus text.
* **English-Only Mandate (Zero Exception Rule):** All content across markdown curriculum files (`.md`), HTML templates, presentation slides (`.pdf`), summary slides, diagrams, banners, and visual image assets (`.png`, `.webp`) must be authored entirely in English (US English). Non-English text, secondary language annotations, or bilingual translations are strictly prohibited.
* **Zero Emojis:** Strictly prohibited across all documentation, markdown files, HTML templates, slide decks, and script outputs.
* **Zero Em/En Dashes:** Em dashes (`—`) and en dashes (`–`) are barred. All textual separators use standard hyphens (`-`) or colons (`:`).
* **Audit-First Methodology:** All numerical figures and metrics must be traceable to primary regulatory filings or verified datasets.

---

## 7. Pre-Flight Quality Assurance Checklist

Before approving or deploying any curriculum deliverable, verify compliance:

1. **Track Validation:** Confirmed whether Course is Track A (Strategy/Theory) or Track B (Applied Coding).
2. **Template Match:**
   - If Track A: Verified presence of Main Theories, SEC 10-K Case, Showdown Slides, and CFO Memo.
   - If Track B: Verified complete ABSENCE of TAM/RBV, absence of showdown slides, and verified presence of Antigravity IDE layout, Style 2 Dual-Pane code slides, and AI error capture protocol.
3. **Visual Asset & Slide Deck Integrity:**
   - 16:9 Banner (`assets/course_banner.png`), 16:9 summary slide (`assets/session_X-Y_slide.png`), 16:9 PDF (`slides/session_X_Y_lecture.pdf`).
   - Canvas Background: **Pure White (`#FFFFFF`)** verified across course banner, summary slides, and presentation slide decks.
   - Fixed coordinate frame with locked footer baseline (`y0` drift = 0 pt).
4. **Editorial Invariants:**
   - 100% zero emojis.
   - 100% zero em/en dashes.
   - Mandatory acronym expansions upon first use.
5. **Language Verification:**
   - 100% English across all markdown files (`.md`), slide decks (`.pdf`), diagrams, and visual image assets (`.png`, `.webp`). Zero non-English characters or secondary annotations.
